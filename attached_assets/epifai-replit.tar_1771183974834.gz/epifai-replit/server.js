const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// Allow Excel to load resources from this origin
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

// Serve the built files from /dist
app.use(express.static(path.join(__dirname, "dist")));

// Serve the manifest at /manifest.xml
app.get("/manifest.xml", (req, res) => {
  res.sendFile(path.join(__dirname, "manifest.xml"));
});

// Fallback to index.html for SPA
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log("");
  console.log("╔══════════════════════════════════════════════╗");
  console.log("║   Epifai Name Manager — Running!              ║");
  console.log("╠══════════════════════════════════════════════╣");
  console.log(`║   Local:  http://localhost:${PORT}               ║`);
  console.log("║                                                ║");
  console.log("║   Next steps:                                  ║");
  console.log("║   1. Copy the Replit URL from the Webview      ║");
  console.log("║   2. Update manifest.xml with that URL         ║");
  console.log("║   3. Upload manifest.xml into Excel            ║");
  console.log("╚══════════════════════════════════════════════╝");
  console.log("");
});
