# Epifai Name Manager — Run on Replit

## Step-by-Step Setup

### 1. Create the Repl

1. Go to https://replit.com and sign in (free account works)
2. Click **+ Create Repl**
3. Choose **Node.js** as the template
4. Name it `epifai-name-manager`
5. Click **Create Repl**

### 2. Upload the files

1. In the Replit file panel (left side), **delete** the default files (`index.js`, etc.)
2. Drag and drop ALL files from this folder into the Replit file panel:
   ```
   .replit
   replit.nix
   package.json
   server.js
   manifest.xml          ← DON'T upload yet, we update this after step 4
   public/
     index.html
     assets/
       logo.png
       icon-16.png
       icon-32.png
       icon-80.png
   src/
     index.jsx
     App.jsx
     services/
       excelNames.js
       excelCharts.js
   webpack.config.js
   ```

### 3. Install & Run

1. Click the **Run** button (or press Ctrl+Enter)
2. Replit will run `npm install` then `npm start`
3. Wait for it to show "webpack compiled successfully"
4. A **Webview** panel opens — you'll see your Replit URL at the top, something like:
   ```
   https://epifai-name-manager.YOUR_USERNAME.repl.co
   ```

### 4. Update the Manifest

1. Copy your Replit URL (e.g. `https://epifai-name-manager.yourname.repl.co`)
2. Open `manifest.xml` in Replit
3. Find & replace ALL instances of:
   ```
   https://localhost:3000
   ```
   with your Replit URL:
   ```
   https://epifai-name-manager.yourname.repl.co
   ```
4. Save the file

### 5. Load into Excel

**Excel Desktop (Windows):**
1. Open Excel
2. **Insert** → **Get Add-ins** → **My Add-ins** (dropdown) → **Upload My Add-in**
3. Upload the `manifest.xml` (download it from Replit first — right-click → Download)
4. Click the **"Name Manager"** button that appears in the **Home** tab

**Excel Online:**
1. Go to https://www.office.com → open any Excel workbook
2. **Insert** → **Office Add-ins** → **Upload My Add-in**
3. Upload `manifest.xml`

### 6. Done!

The add-in now loads from Replit. As long as your Repl is running, 
the manifest works — no local server needed.

---

## Keep It Running

Free Replit Repls go to sleep after inactivity. Options:

- **Replit Deployments (recommended):** Click "Deploy" in Replit → choose "Reserved VM" 
  ($7/month) → your app never sleeps
- **Free workaround:** The Repl wakes up automatically when Excel 
  tries to load the add-in (takes ~10 seconds on first open)
- **Alternative:** Use UptimeRobot (free) to ping your Repl URL every 5 minutes

---

## Troubleshooting

**"Add-in can't be loaded"**
→ Make sure the Repl is running (green "Run" button)
→ Visit your Replit URL in a browser — you should see the loading screen

**Manifest upload rejected**
→ Make sure you replaced ALL `localhost:3000` with your Replit URL
→ The URL must start with `https://`

**Blank panel in Excel**
→ Open the Replit URL in your browser first to wake it up
→ Then re-open the add-in in Excel
