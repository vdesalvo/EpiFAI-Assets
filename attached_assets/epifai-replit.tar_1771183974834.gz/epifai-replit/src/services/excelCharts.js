// Office.js API for Chart management

export async function getAllCharts() {
  return Excel.run(async (ctx) => {
    const sheets = ctx.workbook.worksheets;
    sheets.load("items/name");
    await ctx.sync();
    const results = [];

    for (const sheet of sheets.items) {
      const charts = sheet.charts;
      charts.load("items/name,items/chartType,items/top,items/left,items/width,items/height");
      await ctx.sync();

      for (const chart of charts.items) {
        let dataRange = "", seriesNames = [];
        try {
          const dr = chart.getDataRange(); dr.load("address"); await ctx.sync();
          dataRange = dr.address;
        } catch { dataRange = "(complex source)"; }
        try {
          const s = chart.series; s.load("items/name"); await ctx.sync();
          seriesNames = s.items.map(x => x.name);
        } catch {}

        results.push({
          id: `${sheet.name}__${chart.name}`,
          name: chart.name,
          chartType: mapType(chart.chartType),
          sheet: sheet.name,
          dataRange, series: seriesNames,
          position: { top: chart.top, left: chart.left, width: chart.width, height: chart.height },
        });
      }
    }
    return results;
  });
}

export async function renameChart(sheetName, currentName, newName) {
  return Excel.run(async (ctx) => {
    ctx.workbook.worksheets.getItem(sheetName).charts.getItem(currentName).name = newName;
    await ctx.sync();
  });
}

export async function goToChart(sheetName, chartName) {
  return Excel.run(async (ctx) => {
    const sheet = ctx.workbook.worksheets.getItem(sheetName);
    sheet.activate();
    sheet.charts.getItem(chartName).activate();
    await ctx.sync();
  });
}

export async function getChartImage(sheetName, chartName) {
  return Excel.run(async (ctx) => {
    const img = ctx.workbook.worksheets.getItem(sheetName).charts.getItem(chartName).getImage();
    await ctx.sync();
    return img.value;
  });
}

export function isDefaultName(name) { return /^Chart \d+$/.test(name); }

function mapType(t) {
  const s = String(t).toLowerCase();
  if (s.includes("bar") || s.includes("column")) return "bar";
  if (s.includes("line")) return "line";
  if (s.includes("pie") || s.includes("doughnut")) return "pie";
  if (s.includes("area")) return "area";
  if (s.includes("scatter")) return "scatter";
  return "bar";
}
