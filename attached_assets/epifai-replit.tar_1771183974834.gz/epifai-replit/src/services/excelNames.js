// Office.js API for Named Ranges

export async function getAllNames() {
  return Excel.run(async (ctx) => {
    const wb = ctx.workbook;
    const names = wb.names;
    names.load("items/name,items/type,items/value,items/formula,items/visible,items/comment");
    const sheets = wb.worksheets;
    sheets.load("items/name");
    await ctx.sync();

    const results = [];

    for (const item of names.items) {
      let address = "", values = null, status = "valid";
      try {
        const r = item.getRange();
        r.load("address,values");
        await ctx.sync();
        address = r.address;
        values = r.values;
      } catch { status = "broken"; }

      results.push({
        name: item.name, type: item.type, value: item.value,
        formula: item.formula, comment: item.comment || "",
        visible: item.visible, scope: "Workbook", address, values, status,
      });
    }

    for (const sheet of sheets.items) {
      const sn = sheet.names;
      sn.load("items/name,items/type,items/value,items/formula,items/visible,items/comment");
      await ctx.sync();
      for (const item of sn.items) {
        let address = "", status = "valid";
        try { const r = item.getRange(); r.load("address"); await ctx.sync(); address = r.address; }
        catch { status = "broken"; }
        results.push({
          name: item.name, type: item.type, value: item.value,
          formula: item.formula, comment: item.comment || "",
          visible: item.visible, scope: sheet.name, address, status,
        });
      }
    }
    return results;
  });
}

export async function addName(name, formula, comment = "", scope = "Workbook") {
  return Excel.run(async (ctx) => {
    const item = scope === "Workbook"
      ? ctx.workbook.names.add(name, formula)
      : ctx.workbook.worksheets.getItem(scope).names.add(name, formula);
    if (comment) item.comment = comment;
    await ctx.sync();
  });
}

export async function updateName(name, updates) {
  return Excel.run(async (ctx) => {
    const item = ctx.workbook.names.getItem(name);
    item.load("name,formula,comment");
    await ctx.sync();
    if (updates.refersTo) item.formula = updates.refersTo;
    if (updates.comment !== undefined) item.comment = updates.comment;
    if (updates.newName && updates.newName !== item.name) {
      const f = updates.refersTo || item.formula;
      const c = updates.comment !== undefined ? updates.comment : item.comment;
      item.delete();
      const n = ctx.workbook.names.add(updates.newName, f);
      n.comment = c;
    }
    await ctx.sync();
  });
}

export async function deleteName(name) {
  return Excel.run(async (ctx) => {
    ctx.workbook.names.getItem(name).delete();
    await ctx.sync();
  });
}

export async function goToName(name) {
  return Excel.run(async (ctx) => {
    ctx.workbook.names.getItem(name).getRange().select();
    await ctx.sync();
  });
}

export async function getSelection() {
  return Excel.run(async (ctx) => {
    const r = ctx.workbook.getSelectedRange();
    r.load("address");
    await ctx.sync();
    return r.address;
  });
}

export async function onSelectionChange(cb) {
  let handler;
  await Excel.run(async (ctx) => {
    handler = ctx.workbook.worksheets.getActiveWorksheet().onSelectionChanged.add((e) => cb(e.address));
    await ctx.sync();
  });
  return async () => { await Excel.run(async (ctx) => { handler.remove(); await ctx.sync(); }); };
}
