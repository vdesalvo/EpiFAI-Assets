import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";

Office.onReady((info) => {
  if (info.host === Office.HostType.Excel) {
    createRoot(document.getElementById("root")).render(<App />);
  } else {
    document.getElementById("root").innerHTML =
      '<div style="padding:24px;text-align:center;color:#d13438"><h3>Epifai Name Manager</h3><p>This add-in requires Microsoft Excel.</p></div>';
  }
});
