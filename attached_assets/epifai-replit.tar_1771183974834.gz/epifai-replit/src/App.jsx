import React, { useState, useEffect, useCallback, useRef } from "react";
import * as namesSvc from "./services/excelNames";
import * as chartsSvc from "./services/excelCharts";

// ====== THEME ======
const C = {
  bg: "#fff", surface: "#f0faf7", surfHov: "#e4f5f0", surfAct: "#d4ede6",
  border: "#d0e0db", bFocus: "#3a7d6e", text: "#2c3e50", muted: "#6b8a80",
  bright: "#1a2f3a", accent: "#3a7d6e", accentLt: "#d4f0e8",
  green: "#2d8659", greenBg: "#dff6dd", red: "#d13438", redBg: "#fde7e9",
  orange: "#ca5010", orangeBg: "#fff4ce", navy: "#3d5a80", teal: "#4db8a4",
};

const sty = {
  label: { fontSize: 10, fontWeight: 600, color: C.muted, textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 4 },
  input: { width: "100%", boxSizing: "border-box", padding: "7px 9px", border: `1px solid ${C.border}`, borderRadius: 5, fontSize: 12, color: C.text, outline: "none", background: "#fff" },
  monoInput: { width: "100%", boxSizing: "border-box", padding: "7px 9px", border: `1px solid ${C.border}`, borderRadius: 5, fontSize: 12, color: C.text, fontFamily: "Consolas, 'Courier New', monospace", outline: "none", background: "#fff" },
  btnPrimary: { flex: 1, padding: "9px 0", background: C.accent, color: "#fff", border: "none", borderRadius: 6, fontSize: 12, fontWeight: 700, cursor: "pointer" },
  btnSecondary: { flex: 1, padding: "9px 0", background: "#fff", border: `1px solid ${C.border}`, borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer", color: C.text },
  btnSmall: (bg, fg, brd) => ({ flex: 1, padding: "6px 0", background: bg, color: fg, border: `1px solid ${brd}`, borderRadius: 5, fontSize: 11, fontWeight: 600, cursor: "pointer" }),
};

const Badge = ({ status }) => {
  const m = { valid: [C.greenBg, C.green, "✓"], broken: [C.redBg, C.red, "✕"], unused: [C.orangeBg, C.orange, "–"] }[status] || [C.orangeBg, C.orange, "?"];
  return <span style={{ display: "inline-flex", alignItems: "center", gap: 3, padding: "1px 6px", borderRadius: 10, fontSize: 10, fontWeight: 600, background: m[0], color: m[1] }}><span style={{ fontSize: 8 }}>{m[2]}</span>{status}</span>;
};

const TypeBadge = ({ type }) => {
  const d = type === "dynamic";
  return <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", borderRadius: 10, background: d ? C.accentLt : "#eef2f0", color: d ? C.accent : C.muted, textTransform: "uppercase" }}>{d ? "↕ Dyn" : "⊞ Fix"}</span>;
};

const ChartBadge = ({ type }) => {
  const icons = { bar: "▥", line: "╱", pie: "◔", area: "▨", scatter: "∴" };
  return <span style={{ fontSize: 9, fontWeight: 700, padding: "1px 6px", borderRadius: 10, background: "#e0eaf4", color: C.navy, textTransform: "uppercase" }}>{icons[type] || "▥"} {type}</span>;
};

function isDynamic(formula) {
  if (!formula) return false;
  const u = formula.toUpperCase();
  return u.includes("OFFSET(") || u.includes("INDIRECT(") || u.includes("INDEX(");
}

function toDynFormula(refers) {
  if (!refers) return "";
  const m = refers.match(/^=?(.+)!\$?([A-Z]+)\$?(\d+)(?::\$?([A-Z]+)\$?(\d+))?$/);
  if (!m) return refers;
  const [, sh, c1, r1, c2] = m;
  if (!c2) return refers;
  if (c1 === c2) return `=OFFSET(${sh}!$${c1}$${r1},0,0,COUNTA(${sh}!$${c1}:$${c1})-1,1)`;
  return `=OFFSET(${sh}!$${c1}$${r1},0,0,COUNTA(${sh}!$${c1}:$${c1})-1,${c2.charCodeAt(0) - c1.charCodeAt(0) + 1})`;
}

// ====== MAIN APP ======
export default function App() {
  // Data
  const [names, setNames] = useState([]);
  const [charts, setCharts] = useState([]);
  const [thumbs, setThumbs] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // UI
  const [tab, setTab] = useState("names");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [selId, setSelId] = useState(null);
  const [toast, setToast] = useState(null);

  // Name editing
  const [editId, setEditId] = useState(null);
  const [eName, setEName] = useState("");
  const [eRefers, setERefers] = useState("");
  const [eDesc, setEDesc] = useState("");
  const [eType, setEType] = useState("fixed");
  const [picking, setPicking] = useState(false);
  const unregRef = useRef(null);

  // Chart editing
  const [editChartId, setEditChartId] = useState(null);
  const [ecName, setEcName] = useState("");
  const [ecDesc, setEcDesc] = useState("");

  // ====== LOAD DATA ======
  const loadNames = useCallback(async () => {
    try {
      const data = await namesSvc.getAllNames();
      setNames(data.map((n, i) => ({
        ...n, id: `n-${n.name}-${n.scope}`, color: i % 6,
        desc: n.comment || "", refers: (n.formula || "").replace(/^=/, ""),
        rangeType: isDynamic(n.formula) ? "dynamic" : "fixed",
      })));
    } catch (e) { setError("Failed to load names: " + e.message); }
  }, []);

  const loadCharts = useCallback(async () => {
    try {
      const data = await chartsSvc.getAllCharts();
      setCharts(data.map(c => ({ ...c, isDefault: chartsSvc.isDefaultName(c.name) })));
      // Load thumbnails in background
      for (const c of data) {
        try {
          const img = await chartsSvc.getChartImage(c.sheet, c.name);
          setThumbs(prev => ({ ...prev, [c.id]: img }));
        } catch {}
      }
    } catch (e) { console.error("Charts load error:", e); }
  }, []);

  const refresh = useCallback(async () => {
    setLoading(true); setError(null);
    await Promise.all([loadNames(), loadCharts()]);
    setLoading(false);
  }, [loadNames, loadCharts]);

  useEffect(() => { refresh(); }, [refresh]);

  const flash = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2500); };

  // ====== NAME ACTIONS ======
  const startEditName = (n) => {
    setEditId(n.id); setSelId(n.id); setEName(n.name);
    setERefers(n.refers); setEDesc(n.desc); setEType(n.rangeType);
    setPicking(false);
  };

  const saveEditName = async () => {
    const orig = names.find(n => n.id === editId);
    if (!orig) return;
    try {
      await namesSvc.updateName(orig.name, {
        newName: eName !== orig.name ? eName : undefined,
        refersTo: `=${eRefers}`,
        comment: eDesc,
      });
      flash(`"${eName}" updated`);
      await loadNames();
    } catch (e) { flash(`Error: ${e.message}`); }
    cancelEditName();
  };

  const cancelEditName = () => {
    setEditId(null); setEName(""); setERefers(""); setEDesc("");
    stopPicking(); setPicking(false);
  };

  const deleteNameFn = async (name) => {
    try { await namesSvc.deleteName(name); flash(`"${name}" deleted`); await loadNames(); }
    catch (e) { flash(`Error: ${e.message}`); }
  };

  const goToNameFn = async (name) => {
    try { await namesSvc.goToName(name); } catch (e) { flash(`Error: ${e.message}`); }
  };

  // ====== RANGE PICKER ======
  const startPicking = async () => {
    setPicking(true);
    try {
      const unreg = await namesSvc.onSelectionChange((addr) => setERefers(addr));
      unregRef.current = unreg;
    } catch (e) { console.error("Selection listener error:", e); }
  };

  const stopPicking = async () => {
    setPicking(false);
    if (unregRef.current) { try { await unregRef.current(); } catch {} unregRef.current = null; }
  };

  const togglePicker = () => { picking ? stopPicking() : startPicking(); };

  // ====== CHART ACTIONS ======
  const startEditChart = (ch) => { setEditChartId(ch.id); setEcName(ch.name); setEcDesc(""); };

  const saveEditChart = async () => {
    const orig = charts.find(c => c.id === editChartId);
    if (!orig) return;
    try {
      await chartsSvc.renameChart(orig.sheet, orig.name, ecName);
      flash(`Chart renamed to "${ecName}"`);
      await loadCharts();
    } catch (e) { flash(`Error: ${e.message}`); }
    setEditChartId(null);
  };

  const goToChartFn = async (ch) => {
    try { await chartsSvc.goToChart(ch.sheet, ch.name); } catch (e) { flash(`Error: ${e.message}`); }
  };

  // ====== FILTER ======
  const fNames = names.filter(n => {
    if (filter !== "all" && n.status !== filter) return false;
    if (search && !n.name.toLowerCase().includes(search.toLowerCase()) && !n.desc.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });
  const fCharts = charts.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.sheet.toLowerCase().includes(search.toLowerCase()));
  const stats = { total: names.length, valid: names.filter(n => n.status === "valid").length, broken: names.filter(n => n.status === "broken").length, unused: names.filter(n => n.status === "unused").length };

  const isEditing = editId || editChartId;

  // ====== RENDER ======
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", fontFamily: "'Segoe UI', -apple-system, sans-serif", fontSize: 13, background: "#fff" }}>

      {/* Toast */}
      {toast && <div style={{ position: "fixed", top: 8, left: "50%", transform: "translateX(-50%)", zIndex: 999, background: C.green, color: "#fff", padding: "8px 20px", borderRadius: 6, fontSize: 12, fontWeight: 600, boxShadow: "0 4px 12px rgba(0,0,0,0.25)", whiteSpace: "nowrap" }}>✓ {toast}</div>}

      {/* ===== HEADER ===== */}
      <div style={{ padding: "12px 14px 0", flexShrink: 0, background: `linear-gradient(135deg, ${C.surface}, ${C.surfHov})` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <img src="assets/logo.png" alt="" style={{ width: 30, height: 30, borderRadius: 7 }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 800, fontSize: 16, color: C.navy, letterSpacing: -0.3 }}>Epifai</div>
            <div style={{ fontSize: 9, color: C.muted, fontWeight: 500, letterSpacing: 0.5, textTransform: "uppercase" }}>Name Manager</div>
          </div>
          <button onClick={refresh} title="Refresh from Excel" style={{ background: "none", border: `1px solid ${C.border}`, borderRadius: 5, padding: "5px 10px", cursor: "pointer", fontSize: 12, color: C.muted, display: "flex", alignItems: "center", gap: 4 }}>
            ↻ <span style={{ fontSize: 10 }}>Sync</span>
          </button>
          {isEditing && <span style={{ fontSize: 10, color: C.accent, fontWeight: 700, background: C.accentLt, padding: "3px 8px", borderRadius: 4 }}>EDITING</span>}
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", borderBottom: `1px solid ${C.border}` }}>
          {[{ k: "names", l: "Names", c: names.length, i: "⊞" }, { k: "charts", l: "Charts", c: charts.length, i: "◔" }].map(t => (
            <button key={t.k} onClick={() => { setTab(t.k); cancelEditName(); setEditChartId(null); setSearch(""); }}
              style={{ flex: 1, padding: "9px 0 11px", border: "none", cursor: "pointer", background: "transparent", borderBottom: tab === t.k ? `2.5px solid ${C.accent}` : "2.5px solid transparent", color: tab === t.k ? C.accent : C.muted, fontWeight: tab === t.k ? 700 : 500, fontSize: 12, transition: "all 0.15s" }}>
              {t.i} {t.l} <span style={{ marginLeft: 4, fontSize: 10, padding: "1px 6px", borderRadius: 8, background: tab === t.k ? C.accentLt : "#eef2f0", fontWeight: 700 }}>{t.c}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Loading */}
      {loading && <div style={{ padding: 24, textAlign: "center", color: C.muted, fontSize: 12 }}>
        <div style={{ width: 24, height: 24, border: `3px solid ${C.accentLt}`, borderTopColor: C.accent, borderRadius: "50%", animation: "sp 0.7s linear infinite", margin: "0 auto 8px" }} />
        Reading from Excel...
        <style>{`@keyframes sp{to{transform:rotate(360deg)}}`}</style>
      </div>}

      {/* Error */}
      {error && <div style={{ margin: "8px 14px", padding: 10, background: C.redBg, color: C.red, borderRadius: 6, fontSize: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        {error}
        <button onClick={refresh} style={{ background: "none", border: "none", color: C.red, fontWeight: 700, cursor: "pointer", textDecoration: "underline" }}>Retry</button>
      </div>}

      {/* ====================================================== */}
      {/* ===== NAMES TAB ===== */}
      {/* ====================================================== */}
      {tab === "names" && !loading && (<>

        {/* Filter + Search */}
        {!editId && (
          <div style={{ padding: "10px 14px 8px", borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
            <div style={{ display: "flex", gap: 2, marginBottom: 8, background: "#fff", borderRadius: 7, padding: 3, boxShadow: "0 1px 4px rgba(0,0,0,0.06)" }}>
              {[{ l: "All", c: stats.total, k: "all", cl: C.navy }, { l: "Valid", c: stats.valid, k: "valid", cl: C.green }, { l: "Broken", c: stats.broken, k: "broken", cl: C.red }, { l: "Unused", c: stats.unused, k: "unused", cl: C.orange }].map(s => (
                <button key={s.k} onClick={() => setFilter(s.k)} style={{ flex: 1, border: "none", borderRadius: 5, padding: "4px 2px", cursor: "pointer", textAlign: "center", background: filter === s.k ? C.surface : "transparent", boxShadow: filter === s.k ? "0 1px 3px rgba(58,125,110,0.15)" : "none", transition: "all 0.15s" }}>
                  <div style={{ fontSize: 15, fontWeight: 700, color: s.cl }}>{s.c}</div>
                  <div style={{ fontSize: 8, color: C.muted, textTransform: "uppercase", letterSpacing: 0.5 }}>{s.l}</div>
                </button>
              ))}
            </div>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search names..."
              style={{ ...sty.input, paddingLeft: 10 }} onFocus={e => e.target.style.borderColor = C.accent} onBlur={e => e.target.style.borderColor = C.border} />
          </div>
        )}

        {/* ===== NAME EDIT MODE ===== */}
        {editId ? (() => {
          const orig = names.find(n => n.id === editId);
          const dynF = eType === "dynamic" ? toDynFormula(eRefers) : null;
          const changed = orig && (eName !== orig.name || eRefers !== orig.refers || eDesc !== orig.desc || eType !== orig.rangeType);
          return (
            <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: C.bright, marginBottom: 14 }}>Edit Named Range</div>

              <div style={{ marginBottom: 12 }}>
                <label style={sty.label}>Name</label>
                <input value={eName} onChange={e => setEName(e.target.value)} style={{ ...sty.input, borderColor: C.bFocus, fontWeight: 600 }} />
              </div>

              <div style={{ marginBottom: 12 }}>
                <label style={sty.label}>Refers To</label>
                <div style={{ display: "flex", gap: 4 }}>
                  <input value={eRefers} onChange={e => { setERefers(e.target.value); if (picking) stopPicking(); }}
                    style={{ ...sty.monoInput, flex: 1, borderColor: picking ? C.accent : C.bFocus, background: picking ? C.accentLt : "#fff", boxShadow: picking ? `0 0 0 2px ${C.accent}30` : "none" }} />
                  <button onClick={togglePicker} title={picking ? "Stop picking" : "Pick range on sheet"}
                    style={{ width: 38, height: 36, border: `1px solid ${picking ? C.accent : C.border}`, borderRadius: 5, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", background: picking ? C.accent : "#fff", color: picking ? "#fff" : C.text, fontSize: 16, transition: "all 0.15s" }}>
                    ⬚
                  </button>
                </div>
                {picking && (
                  <div style={{ marginTop: 6, padding: "7px 10px", borderRadius: 5, background: C.accentLt, border: `1px solid ${C.accent}30`, fontSize: 11, color: C.accent, fontWeight: 500 }}>
                    ⬚ Select cells in Excel — the reference updates live
                  </div>
                )}
              </div>

              {/* Range Type */}
              <div style={{ marginBottom: 14 }}>
                <label style={sty.label}>Range Type</label>
                <div style={{ display: "flex", borderRadius: 7, overflow: "hidden", border: `1px solid ${C.border}` }}>
                  {[{ k: "fixed", l: "⊞ Fixed", s: "Exact cells" }, { k: "dynamic", l: "↕ Dynamic", s: "Auto-expand" }].map(o => (
                    <button key={o.k} onClick={() => setEType(o.k)} style={{ flex: 1, border: "none", padding: "10px 6px", cursor: "pointer", background: eType === o.k ? (o.k === "dynamic" ? C.accentLt : C.surfAct) : "#fff", borderRight: o.k === "fixed" ? `1px solid ${C.border}` : "none", transition: "all 0.15s" }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: eType === o.k ? (o.k === "dynamic" ? C.accent : C.bright) : C.muted }}>{o.l}</div>
                      <div style={{ fontSize: 10, color: C.muted, marginTop: 2 }}>{o.s}</div>
                    </button>
                  ))}
                </div>
                {eType === "fixed" && (
                  <div style={{ marginTop: 8, padding: "9px 11px", borderRadius: 6, background: C.surface, border: `1px solid ${C.border}`, fontSize: 11, color: C.muted, lineHeight: 1.5 }}>
                    Points to exact cells. If rows or columns are added, the range <span style={{ fontWeight: 600, color: C.red }}>won't expand</span>.
                  </div>
                )}
                {eType === "dynamic" && (
                  <div style={{ marginTop: 8, padding: "9px 11px", borderRadius: 6, background: "#f0faf7", border: "1px solid #a8ddd0" }}>
                    <div style={{ fontSize: 11, color: C.muted, lineHeight: 1.5, marginBottom: 6 }}>
                      Automatically <span style={{ fontWeight: 600, color: C.green }}>grows or shrinks</span> as data changes.
                    </div>
                    {dynF && (
                      <div style={{ padding: "6px 8px", background: "#fff", borderRadius: 4, border: "1px solid #a8ddd0", fontFamily: "Consolas, monospace", fontSize: 10, color: C.accent, wordBreak: "break-all" }}>{dynF}</div>
                    )}
                    <div style={{ marginTop: 6, display: "flex", gap: 6 }}>
                      <div style={{ flex: 1, padding: "5px", borderRadius: 4, background: C.greenBg, textAlign: "center", fontSize: 10 }}>
                        <div style={{ fontWeight: 700, color: C.green }}>+ Row</div><div style={{ color: C.muted }}>grows ↓</div>
                      </div>
                      <div style={{ flex: 1, padding: "5px", borderRadius: 4, background: C.redBg, textAlign: "center", fontSize: 10 }}>
                        <div style={{ fontWeight: 700, color: C.red }}>− Row</div><div style={{ color: C.muted }}>shrinks ↑</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div style={{ marginBottom: 12 }}>
                <label style={sty.label}>Description</label>
                <input value={eDesc} onChange={e => setEDesc(e.target.value)} placeholder="What is this range for?" style={sty.input} />
              </div>

              {/* Pending changes */}
              {changed && orig && (
                <div style={{ padding: 10, borderRadius: 6, background: "#fffbe6", border: "1px solid #ffd60033", fontSize: 11, marginBottom: 14 }}>
                  <div style={{ fontWeight: 700, color: "#b8860b", marginBottom: 6 }}>Pending Changes</div>
                  {eName !== orig.name && <div style={{ marginBottom: 3 }}><span style={{ color: C.muted }}>Name: </span><span style={{ textDecoration: "line-through", color: C.red }}>{orig.name}</span> → <span style={{ color: C.green, fontWeight: 600 }}>{eName}</span></div>}
                  {eRefers !== orig.refers && <div style={{ marginBottom: 3, fontFamily: "Consolas, monospace", fontSize: 10 }}><span style={{ color: C.muted }}>Range: </span><span style={{ textDecoration: "line-through", color: C.red }}>{orig.refers}</span> → <span style={{ color: C.green, fontWeight: 600 }}>{eRefers}</span></div>}
                  {eType !== orig.rangeType && <div style={{ marginBottom: 3 }}><span style={{ color: C.muted }}>Type: </span><span style={{ textDecoration: "line-through", color: C.red }}>{orig.rangeType}</span> → <span style={{ color: C.green, fontWeight: 600 }}>{eType}</span></div>}
                  {eDesc !== orig.desc && <div><span style={{ color: C.muted }}>Desc: </span><span style={{ color: C.green, fontWeight: 600 }}>{eDesc || "(empty)"}</span></div>}
                </div>
              )}

              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={saveEditName} style={sty.btnPrimary}>✓ Save Changes</button>
                <button onClick={cancelEditName} style={sty.btnSecondary}>Cancel</button>
              </div>
            </div>
          );
        })() : (

          /* ===== NAME LIST ===== */
          <div style={{ flex: 1, overflowY: "auto" }}>
            {fNames.length === 0 && !loading && (
              <div style={{ padding: 24, textAlign: "center", color: C.muted, fontSize: 12 }}>
                {names.length === 0 ? "No named ranges in this workbook." : "No names match your search."}
              </div>
            )}
            {fNames.map(n => (
              <div key={n.id} onClick={() => setSelId(selId === n.id ? null : n.id)}
                style={{ padding: "10px 14px", cursor: "pointer", borderLeft: selId === n.id ? `3px solid ${C.accent}` : "3px solid transparent", background: selId === n.id ? C.accentLt : "transparent", borderBottom: `1px solid ${C.border}18`, transition: "all 0.12s" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
                  <span style={{ fontWeight: 600, fontSize: 13, color: C.bright, flex: 1 }}>{n.name}</span>
                  <TypeBadge type={n.rangeType} />
                  <Badge status={n.status} />
                </div>
                <div style={{ fontSize: 11, color: C.muted, fontFamily: "Consolas, monospace" }}>{n.refers || n.formula}</div>
                {n.scope !== "Workbook" && <span style={{ fontSize: 9, color: "#8764b8", background: "rgba(135,100,184,0.1)", padding: "1px 5px", borderRadius: 3, marginTop: 2, display: "inline-block" }}>Scope: {n.scope}</span>}

                {selId === n.id && (
                  <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>
                    {n.desc && <div style={{ fontSize: 11, color: C.muted, marginBottom: 8, fontStyle: "italic" }}>{n.desc}</div>}
                    {n.address && <div style={{ fontSize: 11, color: C.muted, marginBottom: 4 }}><span style={{ fontWeight: 600, color: C.text }}>Address: </span><span style={{ fontFamily: "Consolas, monospace" }}>{n.address}</span></div>}
                    {n.rangeType === "dynamic" && n.status === "valid" && (
                      <div style={{ marginBottom: 8, padding: "6px 8px", borderRadius: 4, background: "#f0faf7", border: "1px solid #a8ddd0", fontFamily: "Consolas, monospace", fontSize: 10, color: C.accent, wordBreak: "break-all" }}>{toDynFormula(n.refers)}</div>
                    )}
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={e => { e.stopPropagation(); goToNameFn(n.name); }} style={sty.btnSmall(C.accent, "#fff", C.accent)}>Go To Range</button>
                      <button onClick={e => { e.stopPropagation(); startEditName(n); }} style={sty.btnSmall("#fff", C.accent, C.accent)}>✎ Edit</button>
                      {n.status === "broken" && (
                        <button onClick={e => { e.stopPropagation(); startEditName(n); startPicking(); }} style={sty.btnSmall(C.redBg, C.red, `${C.red}40`)}>Repair</button>
                      )}
                    </div>
                    <button onClick={e => { e.stopPropagation(); if (confirm(`Delete "${n.name}"?`)) deleteNameFn(n.name); }}
                      style={{ marginTop: 8, width: "100%", padding: "5px 0", background: "none", border: `1px solid ${C.red}30`, borderRadius: 4, fontSize: 10, color: C.red, cursor: "pointer" }}>
                      Delete this name
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        {!editId && (
          <div style={{ padding: "10px 14px", borderTop: `1px solid ${C.border}`, flexShrink: 0, background: C.surface, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 10, color: C.muted }}>{names.length} names</span>
            <button onClick={async () => {
              const name = prompt("New name (e.g. Revenue_Q1):");
              if (!name) return;
              try {
                const addr = await namesSvc.getSelection();
                await namesSvc.addName(name, `=${addr}`, "");
                flash(`"${name}" created`);
                await loadNames();
              } catch (e) { flash(`Error: ${e.message}`); }
            }} style={{ background: "none", border: "none", color: C.accent, fontSize: 11, fontWeight: 600, cursor: "pointer", textDecoration: "underline" }}>
              + New Name
            </button>
          </div>
        )}
      </>)}

      {/* ====================================================== */}
      {/* ===== CHARTS TAB ===== */}
      {/* ====================================================== */}
      {tab === "charts" && !loading && (<>

        {/* Search */}
        {!editChartId && (
          <div style={{ padding: "10px 14px 8px", borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search charts..."
              style={sty.input} onFocus={e => e.target.style.borderColor = C.accent} onBlur={e => e.target.style.borderColor = C.border} />
            {charts.filter(c => c.isDefault).length > 0 && (
              <div style={{ marginTop: 8, padding: "7px 10px", borderRadius: 5, background: "#fff8e1", border: "1px solid #ffe08250", fontSize: 11, display: "flex", alignItems: "center", gap: 6 }}>
                💡 <span><b>{charts.filter(c => c.isDefault).length}</b> charts have default names</span>
              </div>
            )}
          </div>
        )}

        {/* Chart Edit */}
        {editChartId ? (() => {
          const orig = charts.find(c => c.id === editChartId);
          return (
            <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                {thumbs[editChartId] ? (
                  <img src={`data:image/png;base64,${thumbs[editChartId]}`} alt="" style={{ width: 48, height: 40, borderRadius: 5, objectFit: "cover", border: `1px solid ${C.border}` }} />
                ) : (
                  <div style={{ width: 48, height: 40, borderRadius: 5, background: "#f0f4f8", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>◔</div>
                )}
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: C.bright }}>Rename Chart</div>
                  {orig && <ChartBadge type={orig.chartType} />}
                </div>
              </div>

              <div style={{ marginBottom: 12 }}>
                <label style={sty.label}>Chart Name</label>
                <input value={ecName} onChange={e => setEcName(e.target.value)}
                  style={{ ...sty.input, borderColor: C.accent, borderWidth: 2, fontSize: 14, fontWeight: 600, padding: "9px 11px" }} />
                {orig && ecName === orig.name && chartsSvc.isDefaultName(ecName) && (
                  <div style={{ marginTop: 5, fontSize: 10, color: C.orange, fontStyle: "italic" }}>⚠ Still default name — give it something meaningful</div>
                )}
              </div>

              {orig && (
                <div style={{ padding: 10, borderRadius: 6, background: "#f8f9fa", border: `1px solid ${C.border}`, marginBottom: 12, fontSize: 11 }}>
                  <div style={{ marginBottom: 4 }}><span style={{ color: C.muted }}>Sheet: </span><b>{orig.sheet}</b></div>
                  <div style={{ marginBottom: 4 }}><span style={{ color: C.muted }}>Data: </span><span style={{ fontFamily: "Consolas, monospace", color: C.navy }}>{orig.dataRange}</span></div>
                  {orig.series.length > 0 && (
                    <div style={{ display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
                      <span style={{ color: C.muted }}>Series: </span>
                      {orig.series.map((s, i) => <span key={i} style={{ padding: "1px 6px", borderRadius: 3, fontSize: 10, fontWeight: 600, background: ["#4a90d918", "#5cb85c18", "#f0ad4e18"][i % 3], color: ["#4a90d9", "#5cb85c", "#f0ad4e"][i % 3] }}>{s}</span>)}
                    </div>
                  )}
                </div>
              )}

              {orig && ecName !== orig.name && (
                <div style={{ padding: 10, borderRadius: 6, background: "#fffbe6", border: "1px solid #ffd60033", fontSize: 11, marginBottom: 14 }}>
                  <div style={{ fontWeight: 700, color: "#b8860b", marginBottom: 4 }}>Pending Change</div>
                  <span style={{ textDecoration: "line-through", color: C.red }}>{orig.name}</span> → <span style={{ color: C.green, fontWeight: 600 }}>{ecName}</span>
                </div>
              )}

              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={saveEditChart} style={sty.btnPrimary}>✓ Save</button>
                <button onClick={() => setEditChartId(null)} style={sty.btnSecondary}>Cancel</button>
              </div>
            </div>
          );
        })() : (

          /* Chart List */
          <div style={{ flex: 1, overflowY: "auto" }}>
            {fCharts.length === 0 && !loading && (
              <div style={{ padding: 24, textAlign: "center", color: C.muted, fontSize: 12 }}>
                {charts.length === 0 ? "No charts in this workbook." : "No charts match your search."}
              </div>
            )}
            {fCharts.map(ch => (
              <div key={ch.id} onClick={() => setSelId(selId === ch.id ? null : ch.id)}
                style={{ padding: "12px 14px", cursor: "pointer", borderLeft: selId === ch.id ? `3px solid ${C.navy}` : "3px solid transparent", background: selId === ch.id ? "#edf2f7" : "transparent", borderBottom: `1px solid ${C.border}18`, transition: "all 0.12s" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  {thumbs[ch.id] ? (
                    <img src={`data:image/png;base64,${thumbs[ch.id]}`} alt="" style={{ width: 46, height: 36, borderRadius: 4, objectFit: "cover", border: `1px solid ${C.border}` }} />
                  ) : (
                    <div style={{ width: 46, height: 36, borderRadius: 4, background: "#f0f4f8", border: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, color: C.muted }}>◔</div>
                  )}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: 13, color: ch.isDefault ? C.orange : C.bright }}>{ch.name}</span>
                      {ch.isDefault && <span style={{ fontSize: 9, color: C.orange, background: C.orangeBg, padding: "1px 5px", borderRadius: 8, fontWeight: 700 }}>unnamed</span>}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 2 }}>
                      <ChartBadge type={ch.chartType} />
                      <span style={{ fontSize: 10, color: C.muted }}>{ch.sheet}</span>
                    </div>
                  </div>
                </div>

                {selId === ch.id && (
                  <div style={{ marginTop: 10, paddingTop: 10, borderTop: `1px solid ${C.border}` }}>
                    <div style={{ fontSize: 11, marginBottom: 4 }}><span style={{ color: C.muted }}>Data: </span><span style={{ fontFamily: "Consolas, monospace", color: C.navy }}>{ch.dataRange}</span></div>
                    {ch.series.length > 0 && (
                      <div style={{ fontSize: 11, marginBottom: 6, display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
                        <span style={{ color: C.muted }}>Series: </span>
                        {ch.series.map((s, i) => <span key={i} style={{ padding: "1px 5px", borderRadius: 3, fontSize: 10, fontWeight: 600, background: ["#4a90d918", "#5cb85c18", "#f0ad4e18"][i % 3], color: ["#4a90d9", "#5cb85c", "#f0ad4e"][i % 3] }}>{s}</span>)}
                      </div>
                    )}
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={e => { e.stopPropagation(); goToChartFn(ch); }} style={sty.btnSmall(C.accent, "#fff", C.accent)}>Go To Chart</button>
                      <button onClick={e => { e.stopPropagation(); startEditChart(ch); }} style={sty.btnSmall("#fff", C.accent, C.accent)}>✎ Rename</button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Footer */}
        {!editChartId && (
          <div style={{ padding: "10px 14px", borderTop: `1px solid ${C.border}`, flexShrink: 0, background: C.surface, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 10, color: C.muted }}>{charts.length} charts</span>
            {charts.filter(c => c.isDefault).length > 0 && (
              <button onClick={() => { const un = charts.find(c => c.isDefault); if (un) startEditChart(un); }}
                style={{ background: "none", border: "none", color: C.accent, fontSize: 11, fontWeight: 600, cursor: "pointer", textDecoration: "underline" }}>
                Rename next unnamed
              </button>
            )}
          </div>
        )}
      </>)}
    </div>
  );
}
